import React, { useState } from 'react';
import { Property, Inquiry } from '../types';
import { useLanguage } from './LanguageContext';
import { 
  X, 
  MapPin, 
  Ruler, 
  Compass, 
  IndianRupee, 
  Droplet, 
  CheckCircle2, 
  Calendar, 
  Phone, 
  Send,
  MessageCircle, 
  ChevronLeft, 
  ChevronRight,
  Info
} from 'lucide-react';
import { dbHelper } from '../dbHelper';

interface PropertyDetailsModalProps {
  property: Property;
  onClose: () => void;
  onInquirySubmitted: () => void;
}

export const PropertyDetailsModal: React.FC<PropertyDetailsModalProps> = ({
  property,
  onClose,
  onInquirySubmitted
}) => {
  const { t } = useLanguage();
  const [activePhotoIdx, setActivePhotoIdx] = useState(0);
  const [inquiryName, setInquiryName] = useState('');
  const [inquiryMobile, setInquiryMobile] = useState('');
  const [inquiryMsg, setInquiryMsg] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [alertSuccess, setAlertSuccess] = useState(false);

  // Broker details
  const BROKER_PHONE = "9979912345"; 
  const BROKER_NAME = "Le Vech Property Broker";

  const nextPhoto = () => {
    setActivePhotoIdx((prev) => (prev + 1) % property.photos.length);
  };

  const prevPhoto = () => {
    setActivePhotoIdx((prev) => (prev - 1 + property.photos.length) % property.photos.length);
  };

  const formatPrice = (value: number) => {
    if (value >= 10000000) {
      return `₹${(value / 10000000).toFixed(2)} Crore`;
    }
    if (value >= 100000) {
      return `₹${(value / 100000).toFixed(2)} Lakh`;
    }
    return `₹${value.toLocaleString()}`;
  };

  const handleSendInquiry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inquiryName || !inquiryMobile) return;

    setIsSubmitting(true);
    try {
      await dbHelper.addInquiry({
        propertyId: property.id,
        propertyTitle: `${property.propertyType} in ${property.village}`,
        buyerName: inquiryName,
        buyerMobile: inquiryMobile,
        message: inquiryMsg || `Hi, I am interested in ${property.propertyType} listing inside ${property.village} area. (Survey: ${property.surveyNumber})`,
        createdAt: Date.now(),
        status: 'New'
      });
      // Optionally sync to Contact register as well!
      await dbHelper.addContact({
        name: inquiryName,
        mobile: inquiryMobile,
        role: 'Buyer',
        village: property.village,
        notes: `Inquired about ${property.propertyType} property (Survey: ${property.surveyNumber}) via quick details portal`,
        createdAt: Date.now()
      });

      setAlertSuccess(true);
      setInquiryName('');
      setInquiryMobile('');
      setInquiryMsg('');
      setTimeout(() => {
        setAlertSuccess(false);
        onInquirySubmitted();
      }, 3000);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  // WhatsApp click handler
  const triggerWhatsApp = () => {
    const textMsg = `Hello! I am inquiring about Le Vech Property Hub Listing.\n\n*Property details:*\n- *ID:* ${property.id}\n- *Type:* ${property.propertyType}\n- *Location:* ${property.village}, ${property.taluka}, ${property.district}\n- *Area:* ${property.area}\n- *Price:* ${formatPrice(property.price)}\n- *Survey:* ${property.surveyNumber}.\n\nPlease share more photos or details. Ready to discuss!`;
    const encoded = encodeURIComponent(textMsg);
    window.open(`https://wa.me/91${BROKER_PHONE}?text=${encoded}`, '_blank');
  };

  // Owner/Broker call prompt
  const triggerCall = () => {
    window.location.href = `tel:+91${BROKER_PHONE}`;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="relative bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl w-full max-w-5xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col md:flex-row" id="applet-property-details">
        
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-50 bg-white/80 hover:bg-white dark:bg-zinc-800 dark:hover:bg-zinc-700 p-2 rounded-full cursor-pointer shadow-md text-zinc-800 dark:text-zinc-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Column 1: Image Gallery & Mock Maps Location */}
        <div className="w-full md:w-1/2 flex flex-col border-b md:border-b-0 md:border-r border-zinc-200 dark:border-zinc-800 overflow-y-auto h-full max-h-[45vh] md:max-h-full">
          
          {/* Photos Showcase */}
          <div className="relative h-[280px] sm:h-[350px] bg-zinc-900 flex-shrink-0">
            {property.photos && property.photos.length > 0 ? (
              <>
                <img 
                  referrerPolicy="no-referrer"
                  src={property.photos[activePhotoIdx]} 
                  alt={property.village} 
                  className="w-full h-full object-cover"
                />
                
                {property.photos.length > 1 && (
                  <>
                    <button 
                      onClick={prevPhoto}
                      className="absolute left-3 top-1/2 -translate-y-1/2 bg-black/40 hover:bg-black/60 text-white p-2 rounded-full transition-colors"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <button 
                      onClick={nextPhoto}
                      className="absolute right-3 top-1/2 -translate-y-1/2 bg-black/40 hover:bg-black/60 text-white p-2 rounded-full transition-colors"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                    
                    {/* Index Indicator */}
                    <div className="absolute bottom-3 right-3 bg-black/70 text-white text-xs px-2.5 py-1 rounded-full font-mono">
                      {activePhotoIdx + 1} / {property.photos.length}
                    </div>
                  </>
                )}
              </>
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-zinc-800 text-zinc-500">
                No Photos Available
              </div>
            )}
            
            {/* Type badge overlay */}
            <div className="absolute top-4 left-4 bg-emerald-600 text-white text-xs font-bold px-3 py-1.5 rounded-lg uppercase tracking-wide shadow-sm">
              {property.propertyType}
            </div>
          </div>

          {/* Interactive Google Map Mock */}
          <div className="p-6 border-t border-zinc-100 dark:border-zinc-800 flex-1">
            <h5 className="text-sm font-semibold text-zinc-900 dark:text-zinc-100 flex items-center gap-2 mb-3">
              <MapPin className="w-4 h-4 text-emerald-500" />
              Integrated Geographic Location
            </h5>
            
            {/* Visual Custom Map Pinout Card */}
            <div className="h-[180px] rounded-xl relative overflow-hidden bg-sky-100 dark:bg-emerald-950/20 border border-sky-200 dark:border-emerald-900/40 flex flex-col justify-between p-4">
              {/* Fake Map Grid lines */}
              <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#3b82f6_1px,transparent_1px)] [background-size:16px_16px]"></div>
              
              <div className="relative z-10 flex items-start gap-3">
                <div className="bg-emerald-600 text-white p-2 rounded-lg shrink-0">
                  <MapPin className="w-5 h-5 animate-bounce" />
                </div>
                <div>
                  <h6 className="font-bold text-zinc-800 dark:text-zinc-200 text-sm">
                    {property.village}, {property.taluka}, {property.district}
                  </h6>
                  <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-0.5">Gujarat, India (Geographic Zone)</p>
                  <p className="text-xs text-emerald-600 dark:text-emerald-400 font-mono mt-1">Survey Ref: {property.surveyNumber}</p>
                </div>
              </div>
              
              <div className="relative z-10 flex gap-2 justify-end">
                <a 
                  href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${property.village}, ${property.taluka}, ${property.district}, Gujarat`)}`}
                  target="_blank" 
                  rel="noreferrer"
                  className="bg-white/90 hover:bg-white dark:bg-zinc-800 dark:hover:bg-zinc-700 text-xs text-zinc-800 dark:text-zinc-100 px-3.5 py-1.5 rounded-lg border border-zinc-200 dark:border-zinc-700 shadow-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <Compass className="w-3.5 h-3.5 text-blue-500" />
                  Open in Google Maps
                </a>
              </div>
            </div>
          </div>

        </div>

        {/* Column 2: Detailed Specs & Enquiry Actions */}
        <div className="w-full md:w-1/2 p-6 sm:p-8 overflow-y-auto flex flex-col h-full max-h-[45vh] md:max-h-full">
          <div>
            <span className="text-xs text-zinc-400 dark:text-zinc-500 font-mono">ID: {property.id}</span>
            <h3 className="text-2xl font-black text-zinc-950 dark:text-zinc-100 tracking-tight mt-1">
              {property.propertyType} Field in {property.village}
            </h3>
            <p className="text-sm text-zinc-500 dark:text-zinc-400 flex items-center gap-1 mt-1.5">
              <MapPin className="w-4 h-4 text-zinc-400" />
              {property.village}, {property.taluka}, {property.district}
            </p>

            <div className="mt-4 flex gap-3 flex-wrap">
              <div className="bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-100 dark:border-emerald-900/40 px-3 py-1.5 rounded-lg font-bold text-emerald-700 dark:text-emerald-400 text-sm">
                {property.naNocStatus}
              </div>
              <div className="bg-blue-50 dark:bg-blue-950/50 border border-blue-100 dark:border-blue-900/40 px-3 py-1.5 rounded-lg font-bold text-blue-700 dark:text-blue-400 text-sm">
                {property.roadTouch}
              </div>
            </div>

            {/* Price block */}
            <div className="mt-6 bg-zinc-50 dark:bg-zinc-800/40 border border-zinc-100 dark:border-zinc-800/60 p-4 rounded-2xl flex items-center justify-between">
              <div>
                <span className="text-xs text-zinc-400 dark:text-zinc-500 block uppercase font-bold tracking-wider">{t.price}</span>
                <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400 leading-none">
                  {formatPrice(property.price)}
                </span>
              </div>
              <div className="text-right">
                <span className="text-xs text-zinc-400 dark:text-zinc-500 block uppercase font-bold tracking-wider">{t.area}</span>
                <span className="text-lg font-extrabold text-zinc-800 dark:text-zinc-100 leading-none flex items-center gap-1 justify-end">
                  <Ruler className="w-4 h-4 text-zinc-400" />
                  {property.area}
                </span>
              </div>
            </div>

            {/* Specs Grid */}
            <div className="grid grid-cols-2 gap-4 mt-6">
              <div className="border border-zinc-100 dark:border-zinc-800 p-3 rounded-xl">
                <span className="text-xs text-zinc-400 dark:text-zinc-500 block">{t.surveyNumber}</span>
                <span className="text-sm font-bold text-zinc-800 dark:text-zinc-200 mt-0.5 block font-mono">{property.surveyNumber}</span>
              </div>
              <div className="border border-zinc-100 dark:border-zinc-800 p-3 rounded-xl">
                <span className="text-xs text-zinc-400 dark:text-zinc-500 block">{t.waterAvailability}</span>
                <span className="text-sm font-bold text-zinc-800 dark:text-zinc-200 mt-0.5 block flex items-center gap-1">
                  <Droplet className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                  {property.waterAvailability}
                </span>
              </div>
              <div className="border border-zinc-100 dark:border-zinc-800 p-3 rounded-xl">
                <span className="text-xs text-zinc-400 dark:text-zinc-500 block">{t.taluka}</span>
                <span className="text-sm font-bold text-zinc-800 dark:text-zinc-200 mt-0.5 block">{property.taluka}</span>
              </div>
              <div className="border border-zinc-100 dark:border-zinc-800 p-3 rounded-xl">
                <span className="text-xs text-zinc-400 dark:text-zinc-500 block">{t.district}</span>
                <span className="text-sm font-bold text-zinc-800 dark:text-zinc-200 mt-0.5 block">{property.district}</span>
              </div>
            </div>

            {/* Description */}
            <div className="mt-6">
              <span className="text-xs font-bold uppercase tracking-wider text-zinc-400 dark:text-zinc-500 block">{t.description}</span>
              <p className="text-sm text-zinc-600 dark:text-zinc-300 mt-1.5 leading-relaxed bg-zinc-50/50 dark:bg-zinc-950/20 p-3 rounded-lg border border-zinc-100/50 dark:border-zinc-850">
                {property.description || "No description provided for this listing."}
              </p>
            </div>
          </div>

          {/* Quick Communication Access */}
          <div className="mt-8 pt-6 border-t border-zinc-200 dark:border-zinc-800 space-y-4">
            <h4 className="text-sm font-black text-zinc-900 dark:text-zinc-100 uppercase tracking-widest flex items-center gap-1.5">
              <Info className="w-4 h-4 text-emerald-500" />
              Instant Broker Contact Options
            </h4>
            
            <div className="grid grid-cols-2 gap-3">
              {/* Direct call broker */}
              <button
                onClick={triggerCall}
                className="bg-zinc-900 hover:bg-zinc-805 dark:bg-zinc-100 dark:hover:bg-white text-white dark:text-zinc-900 px-4 py-3 rounded-xl shadow-xs font-bold text-xs tracking-wide shrink-0 inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Phone className="w-4 h-4 text-emerald-500 dark:text-emerald-600" />
                {t.callOwner}
              </button>
              
              {/* WhatsApp direct discussion */}
              <button
                onClick={triggerWhatsApp}
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-3 rounded-xl shadow-xs font-bold text-xs tracking-wide shrink-0 inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <MessageCircle className="w-4 h-4 fill-current" />
                {t.whatsappInquiry}
              </button>
            </div>
          </div>

          {/* Inquiry form section */}
          <div className="mt-8 p-5 bg-zinc-50 dark:bg-zinc-950/50 border border-zinc-100 dark:border-zinc-850 rounded-2xl">
            <h4 className="text-sm font-bold text-zinc-900 dark:text-zinc-100 mb-4 flex items-center gap-1.5">
              <Send className="w-3.5 h-3.5 text-blue-500" />
              Submit Live Site Inquiry
            </h4>

            {alertSuccess ? (
              <div className="bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-900/60 p-4 rounded-xl text-xs font-sans flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                {t.inquirySuccess}
              </div>
            ) : (
              <form onSubmit={handleSendInquiry} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1">{t.buyerName}*</label>
                  <input 
                    type="text" 
                    required 
                    placeholder="Enter your full name"
                    value={inquiryName}
                    onChange={e => setInquiryName(e.target.value)}
                    className="w-full text-sm bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3.5 py-2.5 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 dark:text-zinc-100"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1">{t.buyerMobile}*</label>
                  <input 
                    type="tel" 
                    required 
                    placeholder="Enter 10-digit mobile"
                    value={inquiryMobile}
                    onChange={e => setInquiryMobile(e.target.value)}
                    className="w-full text-sm bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3.5 py-2.5 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 dark:text-zinc-100"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-zinc-600 dark:text-zinc-400 mb-1">{t.message}</label>
                  <textarea 
                    rows={2}
                    placeholder="Optional message (e.g. negotiation, visit timing)"
                    value={inquiryMsg}
                    onChange={e => setInquiryMsg(e.target.value)}
                    className="w-full text-sm bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl px-3.5 py-2.5 focus:outline-hidden focus:ring-1 focus:ring-emerald-500 focus:border-emerald-500 dark:text-zinc-100"
                  />
                </div>
                
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs uppercase tracking-widest py-3 rounded-xl transition-all duration-200 flex justify-center items-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  <Send className="w-3.5 h-3.5" />
                  {isSubmitting ? "Submitting..." : t.submitInquiry}
                </button>
              </form>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};
